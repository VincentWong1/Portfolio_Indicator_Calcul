#!/usr/bin/env python
# -*- coding: utf-8 -*-
from __future__ import unicode_literals

import getopt
import os
import sys

"""
__author__ = 'zhijie.Wang'
__mtime__ = '2018/2/6'
"""

help_str = """
		execute_cmd.py -s <script-name> 被执行python脚本名称，不含扩展名 
               -m --master <master> 执行主节点
               -n --num-executors <num-executors> 计算器数目
               -e --executor-memory <executor-memory> 执行内存
               -d --driver-memory <driver-memory>   驱动内存
               -p --py-files <python files> 程序依赖模块
               -f --files <files> 程序使用文件
    """


def main(argv):
	try:
		opts, args = getopt.getopt(argv, 'hs:m:n:e:d:p:f:',
		                           ['script-name', 'master', 'num-executors', 'executor-memory', 'driver-memory',
		                            'py-files', 'files'])
	except getopt.GetoptError:
		print help_str
		sys.exit(2)
	params = ['yarn-cluster', '20', '2', '4', '', '', '']  # default value
	for opt, arg in opts:
		if opt in ('-h', '--help'):
			print help_str
			sys.exit()
		elif opt in ('-m', '--master'):
			params[0] = arg
		elif opt in ('-n', '--num-executors'):
			params[1] = arg
		elif opt in ('-e', '--executor-memory'):
			params[2] = arg
		elif opt in ('-d', '--driver-memory'):
			params[3] = arg
		elif opt in ('-p', '--py-files'):
			params[4] = arg
		elif opt in ('-f', '--files'):
			params[5] = arg
		elif opt in ('-s', '--script-name'):
			params[6] = arg
	return tuple(params)


def run(args=tuple()):
	cmd = """
	source change_spark_version spark-2.1.0 && /home/bigdata/software/spark-2.1.0.7-bin-2.4.0.10/bin/spark-submit 
	--master %s 
	--num-executors %s 
	--executor-memory %sg 
	--driver-memory %sg 
	--conf spark.default.parallelism=1000
	"""

	if not args.count(''):
		cmd += ' --py-files %s '
		cmd += ' --files %s '
	else:
		tmp = args
		if args.count('') == 1:
			idx = args.index('')
			cmd += ' --py-files %s ' if idx == 5 else ' --files %s '
			args = tmp[:idx] + tmp[idx + 1:]
		else:
			idx = args.index('')
			args = tmp[:idx] + tmp[idx + 2:]
	cmd += ' %s.py'
	os.system(cmd.replace('\n', ' ') % args)


if __name__ == '__main__':
	if len(sys.argv) >= 2:
		run(main(sys.argv[1:]))
	else:
		print help_str
