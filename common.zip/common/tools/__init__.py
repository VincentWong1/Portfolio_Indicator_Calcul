#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
__author__ = 'Zhijie'
__mtime__ = '2018/4/18'
"""
from __future__ import unicode_literals

from datetime import date

from pyspark.sql import functions as func
from pyspark.sql.types import DoubleType

from common.base.spark_operator import SparkOperator
from common.static_values import table_name_values as tb


class Utils(object):
	@staticmethod
	def get_risk_free_rate(cal_date=date.today()):
		"""
		获取特定日期的当前无风险利率
		:param cal_date:获取无风险利率日期
		:return:
		"""
		rf = SparkOperator().get_table(tb.RSK_FREE_TABLE).selectExpr('Effective_Date EDate', 'Dbir_After RFRate')
		rf = rf.withColumn('RFRate', (rf.RFRate.substr(0, 3).cast(DoubleType()) / 100))
		return rf.filter(rf.EDate <= cal_date).agg(func.last(rf.RFRate).alias('RFRate')).collect()[0].RFRate
