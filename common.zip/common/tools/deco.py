#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
__author__ = 'Zhijie'
__mtime__ = '2018/4/19'
"""
from __future__ import unicode_literals

import logging
import time
from functools import wraps

from common.static_values import exception_values as ev
from common.tools.exceptions import QRException

"""
此脚本中编写需要用到的装饰器，如：时间打点，日志，异常捕获...
"""


def exception_handler(func):
	"""
	程序异常捕获装饰器
	"""

	@wraps(func)
	def _wrapper_(*args, **kwargs):

		try:
			logging.log(logging.INFO, '%s start running...' % func.__name__)
			result = func(*args, **kwargs)
			return result
		except QRException as e:
			logging.error('%s throws exception %s' % (func.__name__, e.exception_string))
			raise e
		except Exception as e:
			logging.error('%s throw exception %s' % (func.__name__, e.message))
			raise QRException(
					code=ev.__ERROR_CODE,
					msg='function %s error with exception %s' % (func.__name__, e.message))
		finally:
			logging.log(logging.INFO, '%s finished!' % func.__name__)

	return _wrapper_


def timer(is_use=True):
	def __deco__(func):
		@wraps(func)
		def _deco_(*args, **kwargs):
			if not is_use:
				return func(*args, **kwargs)
			start = time.time()
			ret = func(*args, **kwargs)
			end = time.time()
			print ('function named %s spend %s second!' % (func.__name__, (end - start)))
			return ret

		return _deco_

	return __deco__
