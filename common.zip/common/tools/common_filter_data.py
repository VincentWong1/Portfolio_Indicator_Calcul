#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
__author__ = 'Zhijie'
__mtime__ = '2018/8/16'
"""
from __future__ import unicode_literals

from pyspark.sql import functions as func

from common.base.base_class import BaseClass
from common.static_values import table_name_values as tb


class CommonFilterData(BaseClass):

	def get_period_work_date(self, start, end):
		tmp_data = self.operator.get_table(tb.WRK_DY_TABLE)

		return tmp_data.filter(
				(tmp_data.is_workday == 1) &
				(func.to_date(tmp_data.work_date) >= start) &
				(func.to_date(tmp_data.work_date) <= end)
		).select(func.to_date(tmp_data.work_date).alias('WorkDate')).distinct()


filter_data = CommonFilterData()
