#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
__author__ = 'Zhijie'
__mtime__ = '2018/4/19'
"""
from __future__ import unicode_literals


class QRException(Exception):
	"""
	自定义异常处理类，可以设置自己定义的异常，并用系统的try catch来补获
	"""

	def __init__(self, code, msg, cm_tuple=tuple()):
		"""
		自定义异常类初始化函数，类中有两个私有属性，code msg，可通过两种方式初使化属性值
		1、传入两个参数 code msg,分别赋值给两个参数
		2、传入一个tuple，包含两个元素
		:param code:异常编码
		:param msg:异常信息
		:param cm_tuple:异常编码和信息的元组
		"""
		self.__code = None
		self.__msg = None
		self.set_value(cm_tuple[0], cm_tuple[1]) if cm_tuple else self.set_value(code, msg)

	def set_value(self, code, msg):
		"""
		设置异常类的两个属性值
		:param code:异常编码
		:param msg:异常信息
		:return: None
		"""
		self.__code = code
		self.__msg = msg

	@property
	def exception_string(self):
		"""
		获取对项的异常字符串
		:return:以code和msg组合成的异常字符串
		"""
		return 'Exception occurred with [code=%s, and message=%s]' % (self.__code, self.__msg)
