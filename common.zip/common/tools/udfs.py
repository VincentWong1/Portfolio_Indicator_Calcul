#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
__author__ = 'Zhijie'
__mtime__ = '2018/5/8'
"""
from __future__ import unicode_literals

from uuid import uuid1

import numpy as np
from pyspark.sql import functions as func
from pyspark.sql.types import ArrayType, DoubleType, MapType, ShortType, StringType

# 生成UUID列
from common.tools.utils import to_json

gen_uuid_udf = func.udf(lambda col: uuid1().hex)
# 生成常数列
gen_fix_num_udf = func.udf(lambda col: 1, returnType=ShortType())

element_udf = func.udf(lambda x: x[0], returnType=DoubleType())


# 向量相乘UDF
def vector_multi(col1, col2):
	return float(np.array(col1).dot(np.array(col2).T))


vector_multi_udf = func.udf(vector_multi, returnType=DoubleType())


# 向量规一划
def vector_uniform(col):
	array = np.array(col)
	return (array / np.sum(array)).tolist()


vector_uniform_udf = func.udf(vector_uniform, returnType=ArrayType(DoubleType()))

to_json_udf = func.udf(to_json, returnType=MapType(StringType(), DoubleType()))
