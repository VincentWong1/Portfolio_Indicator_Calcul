#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
__author__ = 'Zhijie'
__mtime__ = '2018/4/18'
"""
from __future__ import unicode_literals

import json
import smtplib
import sys
from datetime import date, datetime
from email.header import Header
from email.mime.text import MIMEText

from pyspark.sql import Window, functions as F


def get_last_quarter(cal_date=date.today()):
	"""
	根据计算日期获取上一个季度的最后一天的日期
	:param cal_date:计算日期 日期格式数据
	:return:上一季度最后天的日期
	"""
	quarter_date = ['03-31', '06-30', '09-30', '12-31']
	if cal_date.month <= 3:
		date_str = '-'.join(map(lambda x: str(x), [cal_date.year - 1, 12, 31]))
	elif cal_date.month <= 6:
		date_str = '-'.join(map(lambda x: str(x), [cal_date.year, quarter_date[0]]))
	elif cal_date.month <= 9:
		date_str = '-'.join(map(lambda x: str(x), [cal_date.year, quarter_date[1]]))
	else:
		date_str = '-'.join(map(lambda x: str(x), [cal_date.year, quarter_date[2]]))
	return date_str


def send_email(
		smtp='mail.cnsuning.com',
		email_from='17111877@cnsuning.com',
		email_from_password='***',
		subject='Something Wrong',
		email_to='17111877@cnsuning.com',
		msg_text=''):
	"""
	发送邮件函数
	:param smtp: 邮件发送服务器
	:param email_from: 发件人邮箱
	:param email_from_password: 发件人密码
	:param subject: 主题
	:param email_to: 收件人邮箱
	:param msg_text: 邮件内容
	:return: None
	"""
	msg = MIMEText(msg_text, 'plain', 'utf-8')
	msg['From'] = email_from
	msg['To'] = email_to
	msg['Subject'] = Header(subject, 'utf-8').encode()
	server = smtplib.SMTP(smtp, 25)  # SMTP协议默认端口是25
	server.login(email_from, email_from_password)
	server.sendmail(
			email_from, [
				email_to, '17111877@cnsuning.com'], msg.as_string())


def seconds_of_days(days=30):
	"""
	天数换算成秒
	:param days: 给定天数
	:return: 天数转换后的秒数
	"""
	return days * 86400


def generate_time_window(partition_col='', order_by_col='', pre_second=None, after_second=0):
	"""
	创建时间创窗口，以对时间窗口内数据进行计算
	:param partition_col: 分区字段
	:param order_by_col: 排序字段
	:param pre_second: 窗口前移秒数
	:param after_second:窗口后移秒数
	:return: 符合条件的窗口
	"""
	if after_second < pre_second:
		raise ValueError("start must less than end")
	window = Window
	if partition_col:
		window = window.partitionBy(partition_col)
	window = window.orderBy(
			F.to_date(order_by_col).cast('timestamp').cast('long').asc()).rangeBetween(pre_second, after_second)
	return window


def fill_na_window(partition_col='', order_by_col='', per_row=-sys.maxsize, after_row=sys.maxsize):
	if after_row < per_row:
		raise ValueError('Start must less than end')
	window = Window
	if partition_col:
		window = window.partitionBy(partition_col)
	if order_by_col:
		window = window.orderBy(order_by_col.asc())
	return window.rowsBetween(per_row, after_row)


def date_from_param(data='2017-1-1'):
	"""
	通过参数获取日期数据，兼容str, unicode, date, datetime 等格式
	:param data: 输入数据
	:return: date类型的日期数据
	"""
	if isinstance(data, date):
		return data
	if isinstance(data, str) or isinstance(data, unicode):
		return datetime.strptime(data, '%Y-%m-%d').date()
	if isinstance(data, datetime):
		return data.date()
	raise ValueError('Input param type can not cast to date type!')


def datestr_from_param(data='2017-7-7'):
	"""
	获取字日期字符串
	:param data: 输入的日期数据，兼容各种类型
	:return:日期的字符串形式
	"""
	return str(date_from_param(data))


def to_json(json_str=None):
	return json.loads(json_str)
