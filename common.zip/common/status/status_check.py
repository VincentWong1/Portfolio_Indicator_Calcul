#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
__author__ = 'Zhijie'
__mtime__ = '2018/8/24'
"""
from __future__ import unicode_literals

from common.base.base_class import BaseClass


class StatusCheck(BaseClass):

	def __init__(self, tb_name=None, columns=None):
		BaseClass.__init__(self)
		self.__tb_name = tb_name
		self.__columns = columns

	@property
	def table_name(self):
		return self.__tb_name

	@property
	def columns(self):
		return self.__columns

	def update(self, **kwargs):
		raise NotImplementedError

	def check(self, **kwargs):
		raise NotImplementedError
