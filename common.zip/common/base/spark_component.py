#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
__author__ = 'Zhijie'
__mtime__ = '2018/5/8'
"""
from __future__ import unicode_literals

from common.base.spark_operator import SparkOperator
from common.static_values import table_name_values as tb


def fund_base_info(*args, **kwargs):
	"""
	获取基金基本信息表
	:param args:所选字段
	:param kwargs:筛选条件
	:return:
	"""
	return SparkOperator(app_name='component').filter_table_data(tb.FND_FUND_ARCHIIVES, *args, **kwargs)
