#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
__author__ = 'Zhijie'
__mtime__ = '2018/9/18'
"""
from __future__ import unicode_literals

from functools import wraps


class BaseSingleton(object):
	__instance = None

	def __new__(cls, *args, **kwargs):
		if not cls.__instance:
			cls.__instance = super(BaseSingleton, cls).__new__(cls, *args, **kwargs)
		return cls.__instance


def singleton(cls):
	instance = {}

	@wraps(cls)
	def get_instance(*args, **kwargs):
		if cls not in instance:
			instance[cls] = cls(*args, **kwargs)
		return instance[cls]

	return get_instance


class Singleton(type):
	_instances = {}

	def __call__(cls, *args, **kwargs):
		if cls not in cls._instances:
			cls._instances[cls] = super(Singleton, cls).__call__(*args, **kwargs)
		return cls._instances[cls]
