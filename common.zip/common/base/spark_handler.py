#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
__author__ = 'Zhijie'
__mtime__ = '2018/9/28'
"""
from __future__ import unicode_literals

from common.base.spark_operator import SparkOperator


class SparkHandler(object):
	operator = SparkOperator(app_name='Zj', log_level='ERROR')
	spark = operator.spark
