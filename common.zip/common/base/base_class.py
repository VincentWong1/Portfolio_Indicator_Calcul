#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
__author__ = 'Zhijie'
__mtime__ = '2018/6/6'
"""
from __future__ import unicode_literals

from common.base.spark_operator import operator


class BaseClass(object):

	def __init__(self):
		self.__operator = operator  # SparkOperator(app_name='ZJ', log_level='ERROR')

	@property
	def operator(self):
		return self.__operator

	@property
	def spark(self):
		return self.operator.spark
