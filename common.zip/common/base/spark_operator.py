#!/usr/bin/env python
# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from pyspark.sql import SQLContext, SparkSession

from common.base.base_singleton import BaseSingleton

"""
__author__ = 'zhijie'
__mtime__ = '2018/2/2'
"""


class SparkOperator(BaseSingleton):
	"""
	Spark操作类，包括取数据，建表保存数据等等
	"""

	def __init__(
			self,
			app_name='',
			log_level='WARN',
			hive_support=True,
			exe_mem='16g',
			exe_cores='2',
			max_cores='4',
			**kwargs
	):
		"""
		初始化函数
		:param app_name:应用名称
		:param log_level:日地等级
		:param hive_support:是否支持HIVE
		:param exe_mem:执行内存
		:param exe_cores:执行器数量
		:param max_cores:最大执行器数量
		"""
		self.__app_name = app_name
		self.__log_level = log_level
		self.__hive_support = hive_support
		self.__exe_mem = exe_mem
		self.__exe_cores = exe_cores
		self.__max_cores = max_cores
		self.__spark = None
		self.__config = kwargs

	@property
	def spark(self):
		"""
		Spark属性，返回一个Spark对象
		:return:SparkSession对象
		"""
		if not self.__spark:
			spark = SparkSession.builder \
				.appName(self.__app_name) \
				.config('log4j.rootCategory', self.__log_level)
			if self.__hive_support:
				spark = spark.enableHiveSupport()
			spark = spark.getOrCreate()
			spark.conf.set('spark.default.parallelism', 1000)
			spark.conf.set('spark.sql.execution.arrow.enabled', True)
			# spark.conf.set('spark.storage.memoryFraction', 0.5)
			# spark.conf.set('spark.shuffle.memoryFraction', 0.3)
			if self.__exe_mem:
				spark.conf.set('spark.executor.memory', '%sg' % self.__exe_mem)
			if self.__exe_cores:
				spark.conf.set('spark.executor.cores', self.__exe_cores)
			if self.__max_cores:
				spark.conf.set('spark.cores.max', self.__max_cores)
			if self.__config:
				map(lambda x: spark.conf.set(x.replace('_', '.'), self.__config.get(x)), self.__config.keys())
			self.__spark = spark
		return self.__spark

	@property
	def context(self):
		"""
		:return:上下文对象
		"""
		return self.spark.sparkContext

	@property
	def sql_context(self):
		return SQLContext(self.context, self.spark)

	def execute_sql(self, sql='', enable_join=False):
		"""
		以Spark方式执行HIVE SQL,该函数保留但不推荐使用
		:param sql:SQL语句
		:param enable_join:是否支持crossJoin
		:return:
		"""
		if enable_join:
			self.spark.conf.set("spark.sql.crossJoin.enabled", 'true')
		else:
			self.spark.conf.set('spark.sql.crossJoin.enabled', 'false')
		return self.spark.sql(sql)

	def get_table(self, table_name=''):
		"""
		获取全表数据
		:param table_name:表名
		:return:表数据Spark DataFrame
		"""
		self.refresh_table(table_name)
		return self.spark.table(tableName=table_name)

	def filter_table_data(self, table_name=None, *args, **kwargs):
		"""
		从HIVE库中获取符合条件
		:param table_name: select table name
		:param args: needed table field
		:param kwargs: select condition; if the condition is a<1 the param should set a='<1'
		:return: data which match the select condition date_type:Spark DataFrame
		"""
		if not args:
			args = tuple('*')
		if not kwargs:
			ret = self.get_table(table_name).select(*args)
		else:
			ret = self.get_table(table_name).select(*args).filter(self.condition_consist(**kwargs))
		return ret

	def condition_consist(self, **kwargs):
		"""
		consist the input condition
		:param kwargs:condition dict
		:return: sql filter condition str
		"""
		ret = []
		for key in kwargs.keys():
			if isinstance(kwargs.get(key), list):
				ret.extend(map(lambda x: '%s %s' % (key, x), kwargs.get(key)))
			elif isinstance(kwargs.get(key), tuple):
				ret.append('(' + ' or '.join(map(lambda x: '%s %s' % (key, x), kwargs.get(key))) + ')')
			else:
				ret.append('%s %s' % (key, kwargs.get(key)))
		return ' and '.join(ret)

	def is_table_exists(self, table_name=None):
		db_name, table_name = table_name.split('.')
		catalog = self.spark.catalog
		catalog.setCurrentDatabase(db_name)
		df = self.execute_sql("""show tables like '%s'""" % table_name)
		if df.count() == 1:
			return True
		return False

	def is_table_schema_equals_dataframe(self, table_name=None, dataframe=None):
		tb = self.get_table(table_name)
		if sorted(tb.dtypes, key=lambda x: x[0]) == sorted(dataframe.dtypes, key=lambda x: x[0]):
			return True
		return False

	def create_table(self, table_name=None, field_names=list(), field_types=list(), **kwargs):
		"""
		创建表函数，传入表名和字段名称和类型，在hive库中建表
		:param table_name: 表名
		:param field_names: 字段名列表 元素为字符型
		:param field_types: 类型名列表 元素为字符型
		:param kwargs: 字段名称类型字段 形如: create('table_name', id='string', name='string',age='int')
		:return:None
		"""

		create_table_sql = """CREATE TABLE IF NOT EXISTS %s (%s)"""
		partition_col = kwargs.get('partition_col')
		if partition_col:
			partition_lst = []
			column_lst = []
			for col in partition_col:
				for idx in range(len(field_names)):
					if col == field_names[idx]:
						partition_lst.append('\t'.join([field_names[idx], field_types[idx]]))
					else:
						column_lst.append('\t'.join([field_names[idx], field_types[idx]]))
			partition_str = ','.join(partition_lst)
			column_str = ','.join(column_lst)
			self.execute_sql(create_table_sql + """partitioned by (%s)""" % (table_name, column_str, partition_str))
		else:
			column_str = ','.join(map(lambda x, y: '\t'.join([x, y]), field_names, field_types))
			self.execute_sql(create_table_sql % (table_name, column_str))

	def drop_table(self, table_name=None):
		"""
		根据表名删除hive库中的表
		:param table_name:
		:return:
		"""
		self.execute_sql("""DROP TABLE if EXISTS %s """ % table_name)

	def save(self, table_name=None, data_frame=None, overwrite=False, partition_cols=None):
		"""
		将Spark DataFrame中的数据落到表中
		:param table_name:表名
		:param data_frame:要保存的数据
		:param overwrite:是否覆盖式保存，if true 清除原来数据保存新数据 if false 增量保存数据
		:return:
		"""

		writer = data_frame.write.format('parquet')
		# 数据写入模式 overwrite 覆盖，append 添加
		if overwrite:
			writer = writer.mode('overwrite')
		else:
			writer = writer.mode('append')

		# 判断表是否存在，存在即用insertInto,表不存在使用saveAsTable,并添加相应的分区
		if self.is_table_exists(table_name):
			writer.insertInto(table_name, overwrite)
		else:
			if partition_cols:
				if not isinstance(partition_cols, tuple) and not isinstance(partition_cols, list):
					partition_cols = [partition_cols]
				writer = writer.partitionBy(*partition_cols)
			writer.saveAsTable(table_name)
		self.refresh_table(table_name)

	def refresh_table(self, table_name):
		self.execute_sql('REFRESH TABLE %s' % table_name)


operator = SparkOperator(app_name='tst', log_level='ERROR')
spark = operator.spark
