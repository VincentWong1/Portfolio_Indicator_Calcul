#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
__author__ = 'Zhijie'
__mtime__ = '2018/6/14'
"""
from __future__ import unicode_literals

import sys

from pyspark.sql import Window, functions as func


def generate_time_window(partition_col='', order_by_col='', pre_second=None, after_second=0):
	"""
	创建时间创窗口，以对时间窗口内数据进行计算
	:param partition_col: 分区字段
	:param order_by_col: 排序字段
	:param pre_second: 窗口前移秒数
	:param after_second:窗口后移秒数
	:return: 符合条件的窗口
	"""
	if after_second < pre_second:
		raise ValueError("start must less than end")
	window = Window
	if partition_col:
		window = window.partitionBy(partition_col)
	window = window.orderBy(
			func.to_date(order_by_col).cast('timestamp').cast('long').asc()).rangeBetween(pre_second, after_second)
	return window


def fill_na_window(partition_col='', order_by_col='', per_row=-sys.maxsize, after_row=sys.maxsize):
	if after_row < per_row:
		raise ValueError('Start must less than end')
	window = Window
	if partition_col:
		window = window.partitionBy(partition_col)
	if order_by_col:
		window = window.orderBy(func.to_date(order_by_col).asc())
	return window.rowsBetween(per_row, after_row)


def normal_window_without_rank(partition_cols=[], order_by_cols=[]):
	"""
	:param partition_cols: 分区字段列表
	:param order_by_cols:  排序字段列表
	:param ascending: 是否升序
	:return:
	"""
	window = Window
	if partition_cols:
		window = window.partitionBy(*tuple(partition_cols))
	if order_by_cols:
		window = window.orderBy(*tuple(order_by_cols))
	return window


def normal_window(partition_cols=[], order_by_cols=[], pre_row=-sys.maxsize, after_row=sys.maxsize):
	if after_row < pre_row:
		raise ValueError('Start must less than end!')
	window = normal_window_without_rank(partition_cols, order_by_cols)
	return window.rowsBetween(pre_row, after_row)
