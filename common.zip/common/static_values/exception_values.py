#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
__author__ = 'Zhijie'
__mtime__ = '2018/4/18'
"""
from __future__ import unicode_literals

# 异常常量
from enum import Enum


class ExceptionCode(Enum):
	PROCESS_SUCCESS = 1000
	PROCESS_UNKNOWN_ERROR = 1001


class ExceptionMessage(Enum):
	PROCESS_SUCCESS = '程序执行成功'
	PROCESS_UNKNOWN_ERROR = '程序执行未知异常'


class ExceptionValue(Enum):
	def __init__(self, code, msg):
		self.__code = code
		self.__msg = msg

	@property
	def exception_msg(self):
		return 'error_code:[%s], error_msg:[%s]' % (self.__code.value, self.__msg.value)

	PROCESS_SUCCESS = (ExceptionCode.PROCESS_SUCCESS, ExceptionMessage.PROCESS_SUCCESS)
	PROCESS_UNKNOWN_ERROR = (ExceptionCode.PROCESS_UNKNOWN_ERROR, ExceptionMessage.PROCESS_UNKNOWN_ERROR)
