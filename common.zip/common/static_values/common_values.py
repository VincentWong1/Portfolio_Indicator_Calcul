#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
__author__ = 'Zhijie'
__mtime__ = '2018/4/18'
"""
from __future__ import unicode_literals

from datetime import date

FUND_BASE_KWARGS = {'min_amount': 100, 'min_hold': 100, 'fund_size': 1000000000, 'type': 2,
                    'fund_type':  0,
                    'start_date': '2014-1-1', 'management_time': 720, 'is_init_fund': 1,
                    'is_fof':     2}
FUND_ASSET_KWARGS = FUND_BASE_KWARGS.copy()
FUND_ASSET_KWARGS.update({'end_date': date.today()})
FUND_DAILY_VALUE_KWARGS = {'fund_code': '1001', 'start_date': '2017-1-1', 'end_date': None}

FUND_ASSET_POOL = FUND_ASSET_KWARGS.copy()
FUND_ASSET_POOL.update({'risk_free_rate': 0.038, 'threshold': 1.5})

SPARK_TMP_PORTFOLIO_TABLE_NAME = 'fbidm.fnd_rb_adv_tmp_portfolio_half_year'
SPARK_PORTFOLIO_TABLE_NAME = 'fbidm.fnd_rb_adv_portfolio_half_year'
SPARK_ASSET_DICT_TMP_TABLE = 'fbidm.fnd_rb_adv_dct_data_half_year'

__EXCEPTION_SUCCESS_CODE = 0000
__EXCEPTION_SUCCESS_MSG = '程序执行成功！'
EXCEPTION_SUCCESS = (__EXCEPTION_SUCCESS_CODE, __EXCEPTION_SUCCESS_MSG)

EXCEPTION_FAILED_CODE = 1001
EXCEPTION_FAILED_MSG = '程序执行失败！'
