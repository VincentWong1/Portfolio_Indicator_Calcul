#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
__author__ = 'Zhijie'
__mtime__ = '2018/6/7'
"""
from __future__ import unicode_literals

from pyspark.sql import functions as f

from common.base.base_class import BaseClass
from common.tools.udfs import gen_uuid_udf


class BaseEtl(BaseClass):
	def __init__(self, df=None):
		BaseClass.__init__(self)
		self.__df = self.etl() if not df else df

	def etl(self):
		pass

	@property
	def cols(self):
		return self.__df.columns

	@property
	def types(self):
		return self.__df.dtypes

	@property
	def data(self):
		data = self.__df.na.drop(how='all')
		return data

	def get_update_data(self, output_table='', drop_unique_cols=(), cols_order=()):
		"""
		获取增量数据，计算全量数据与表中数据对比，去除重复数据
		:param output_table: 输出表的名称
		:param drop_unique_cols: 删除影响去重列
		:return: 增量数据
		"""

		result = self.data
		if_same_struct = True
		if self.operator.is_table_exists(output_table):
			hist_data = self.operator.get_table(output_table)
			hist_cols = hist_data.columns
			hist_data = hist_data.drop(*tuple(drop_unique_cols))
			if sorted(hist_cols) == sorted(cols_order):
				result = result.select(*tuple(hist_data.columns))
				if sorted(hist_data.dtypes, key=lambda x: x[0]) == sorted(result.dtypes, key=lambda x: x[0]):
					result = result.subtract(hist_data)
				else:
					if_same_struct = False
			else:
				if_same_struct = False
		if not if_same_struct:
			raise ValueError('The dataframe schema is not same with exists table')
		return result

	def save(
			self, output_table='', drop_unique_cols=(), cols_order=(), if_add_id=True, if_add_updatetime=True,
			overwrite=False, partition_cols=None
	):
		"""
		保存ETL结果
		:param output_table:表名
		:param drop_unique_cols:删除影响去重列
		:param cols_order:数据列排序
		:return:无
		"""
		# 用UDF添加uuid及updatetime字段，并按要求排序列字段
		data = self.get_update_data(output_table, drop_unique_cols, cols_order) if not overwrite else self.data
		if if_add_id:
			data = data.withColumn('Id', gen_uuid_udf(cols_order[1]))
		if if_add_updatetime:
			data = data.withColumn('UpdateTime', f.current_timestamp())
		data = data.select(*cols_order)
		self.operator.save(output_table, data, overwrite, partition_cols)
