#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
__author__ = 'Zhijie'
__mtime__ = '2018/8/21'
"""
from __future__ import unicode_literals

from common.base.base_class import BaseClass
from common.base.spark_operator import SparkOperator


class Transform(BaseClass):
	def __init__(self, table_name=None, partitions=[], **kwargs):
		"""
		转换类的初始函数
		:param table_name:需要转换数据的表名
		:param partitions:需要转换数据的分区 [("partition1='some_value'","partition2='some_value'")]
		:param kwargs:其它筛选条件
		"""
		BaseClass.__init__(self)

		self.__table_name = table_name
		self.__partitions = partitions if partitions else []
		self.__params = kwargs
		self.__tmp_table = None

	@property
	def table_name(self):
		return self.__table_name

	@property
	def partitions(self):
		return self.__partitions

	@property
	def params(self):
		return self.__params

	@property
	def filter_condition(self):
		condition = ''
		if self.partitions:
			condition += ' or '.join(map(lambda x: '(' + ' and '.join(x) + ')', self.partitions))

		if self.params:
			condition += SparkOperator.condition_consist(self.params)

		return condition

	@property
	def origin_data(self):
		tmp_data = self.operator.get_table(self.table_name)
		if self.filter_condition:
			tmp_data = tmp_data.filter(self.filter_condition)
		return tmp_data

	def cache_data(self):
		self.spark.sql_context.cacheTable()

	def transform(self):
		raise NotImplementedError

	def delete_partitions(self):
		for partition in self.partitions:
			self.spark.execute_sql("""
			ALTER TABLE %s DROP IF EXISTS PARTITION (%s);
			""" % (self.table_name, ','.join(partition)))

	def save_transform_data(self, over_write=False):
		self.operator.save(self.table_name, self.transform(), overwrite=over_write, partition_cols=[])
