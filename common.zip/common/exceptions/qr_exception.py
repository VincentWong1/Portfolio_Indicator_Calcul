#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
__author__ = 'Zhijie'
__mtime__ = '2018/10/29'
"""
from __future__ import unicode_literals


class QRException(Exception):
	def __init__(self, exception_value=None):
		self.__exception_value = exception_value

	@property
	def exception_value(self):
		return self.__exception_value

	@property
	def message(self):
		return self.exception_value.exception_msg
